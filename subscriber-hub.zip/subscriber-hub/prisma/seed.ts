import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  // Replace these with your 3 actual paper names/slugs.
  const papers = await Promise.all([
    prisma.paper.upsert({
      where: { slug: "daily-gazette" },
      update: {},
      create: { name: "The Daily Gazette", slug: "daily-gazette" },
    }),
    prisma.paper.upsert({
      where: { slug: "morning-tribune" },
      update: {},
      create: { name: "The Morning Tribune", slug: "morning-tribune" },
    }),
    prisma.paper.upsert({
      where: { slug: "weekly-courier" },
      update: {},
      create: { name: "The Weekly Courier", slug: "weekly-courier" },
    }),
  ]);

  const subscriber = await prisma.subscriber.upsert({
    where: { email: "test.subscriber@example.com" },
    update: {},
    create: {
      firstName: "Test",
      lastName: "Subscriber",
      email: "test.subscriber@example.com",
      deliveryAddressLine1: "123 Main St",
      deliveryCity: "Denver",
      deliveryState: "CO",
      deliveryZip: "80202",
    },
  });

  await prisma.subscription.upsert({
    where: { id: "seed-subscription-1" },
    update: {},
    create: {
      id: "seed-subscription-1",
      subscriberId: subscriber.id,
      paperId: papers[0].id,
      type: "PRINT_DIGITAL",
      tier: "monthly",
      status: "ACTIVE",
      startDate: new Date(),
      renewalDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30),
    },
  });

  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
